package com.example.app_media_caio;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edt_kminicial, edt_kmfinal, edt_litros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        edt_kminicial = findViewById(R.id.edt_kminicial);
        edt_kmfinal = findViewById(R.id.edt_kmfinal);
        edt_litros = findViewById(R.id.edt_litros);

    }
    public void calcular_clique(View v) {

        String str_kminicial = edt_kminicial.getText().toString();
        String str_kmfinal = edt_kmfinal.getText().toString();
        String str_litros = edt_litros.getText().toString();

        if(str_kminicial.equals("") || str_kmfinal.equals("") || str_litros.equals("")){

            Toast.makeText(MainActivity.this,
                    "Preencha todos os campos. ",
                    Toast.LENGTH_SHORT).show();

        }

        else {

        double kminicial = Double.parseDouble(str_kminicial);
        double kmfinal = Double.parseDouble(str_kmfinal);
        double litros = Double.parseDouble(str_litros);

        double media = (kmfinal - kminicial) / litros;

        if (kminicial > kmfinal) {
            Toast.makeText(MainActivity.this,
                    "quilometragem inicial não pode ser maior que o final. ",
                    Toast.LENGTH_LONG).show();
        } else {
            String msg;

            if (media <= 7) {
                msg = "Carro com problema! ";
            } else {
                msg = "Carro está normal. ";
            }

            AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
            alertDialog.setTitle("Resultado");
            alertDialog.setMessage(media + " Km/h \n" + msg);
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }
        }
    }
    public void limpar_clique(View v){
        edt_kminicial.setText("");
        edt_kmfinal.setText("");
        edt_litros.setText("");

        Toast.makeText(MainActivity.this,
                "Limpado",
                Toast.LENGTH_SHORT).show();
    }
}